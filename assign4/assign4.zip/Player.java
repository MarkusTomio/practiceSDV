package sdvP_assign4;

public class Player {

	// variables as defined by instructions
	private int x;
	private int y;
	private int energy;

	public Player(int mazeSize) {
		this.x = 0;
		this.y = 0;

		// i have chosen energy level to be 0.6 of the number of tiles. Chosen out of
		// pure intuition. Math.round seems more player friendly than only
		// casting. Recast to int is necessary, because Math.round returns long.
		this.energy = (int) Math.round(mazeSize * mazeSize * 0.6);
	}

	// getters as defined by instructions
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getEnergy() {
		return energy;
	}

	// methods as defined by instructions. player positions get in-/decreased
	// according to player action. after each move, energy is lowered by one.
	public void moveUp() {
		y++;
		energy--;
	}

	public void moveDown() {
		y--;
		energy--;
	}

	public void moveLeft() {
		x--;
		energy--;
	}

	public void moveRight() {
		x++;
		energy--;
	}

}

package sdvP_assign4;

public class Tile {

	// variables as defined by instructions
	private boolean isWall;
	private boolean isExit;

	public Tile(boolean isWall, boolean isExit) {
		this.isWall = isWall;
		this.isExit = isExit;
	}

	// getters as defined by instructions
	public boolean isWall() {
		return isWall;
	}

	public boolean isExit() {
		return isExit;
	}

}

package sdvP_assign4;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		// welcome and request maze dimensions from user
		System.out.println("Welcome player, to the aMAZEing game.\n\n"
				+ "First, you will have to enter size of the maze. You can enter only ONE positive integer, as the maze must be a square grid.\n\nSize: ");

		/*
		 * the size of the maze is chosen by user input. However, a maze smaller than or
		 * equal to 1x1 does not make sense. With size 0x0 there is no maze at all, with
		 * size 1x1 also not really and exit would than have to be on (0, 0), which is
		 * not allowed. To not overfill main method, I have chosen to use a seperate
		 * helper method for input validation.
		 *
		 * define scanner for user input here, so it can be used for movement input as
		 * well. I thought about having one scanner for mazeSize within the
		 * validateInput method and a seperate one for movement. But then i would have
		 * to close the mazeSize scanner in that method as well and i read online, that
		 * closing one scanner (system.in) and then still using the other can lead to
		 * problems. So, one for all it is.
		 */

		Scanner sc = new Scanner(System.in);
		// method will return valid input and store it in this variable
		int mazeSize = validateInput(sc);

		// new maze with given dimensions
		Maze maze = new Maze(mazeSize);

		// give corresponding feedback output for the user
		System.out.println(
				"\nA maze with the chosen size of " + maze.getSize() + " x " + maze.getSize() + " has been created.");

		// create player and variable to store movement input
		Player p = new Player(maze.getSize());
		String moveDir;

		/*
		 * this is the main game loop. Hey Omid, do you actually read all of this? Hope
		 * you are having a great day :) So, it keeps on loopin' as long as the player
		 * has not used up their energy limit and has not found the exit. In other
		 * words, we keep looping until the opposite of at least one termination cond is
		 * false. Because then one termination cond is true. Hard to describe.
		 */
		while (p.getEnergy() > 0 && !maze.getTile(p.getX(), p.getY()).isExit()) {

			// feedback output for the user, displaying current pos, energy lvl and
			// potential inputs
			System.out.println("\nYour current position is (" + p.getX() + ", " + p.getY()
					+ ").\n\nYour current energy level is " + p.getEnergy()
					+ "\n\nPress\nW to move up\nA to move left\nS to move down\nD to move right");

			// scan user input
			moveDir = sc.nextLine().toUpperCase();

			/*
			 * So, this is the core of the movement functionality. For each WASD is checked
			 * if the move does not exit the field and not hit a wall. If that's the case,
			 * the move is executed via corresponding Player class method. If it's not the
			 * case, we check what the issue is and give corresponding feedback output to
			 * the user. If the input is none of WASD, also give corresponding feedback
			 * output.
			 */
			if (moveDir.equals("W") && p.getY() < mazeSize - 1 && !maze.getTile(p.getX(), p.getY() + 1).isWall()) {
				p.moveUp();
			} else if (moveDir.equals("W") && p.getY() == mazeSize - 1) {
				System.out.println("\nCannot leave the maze. Try a different direction.");
			} else if (moveDir.equals("W") && maze.getTile(p.getX(), p.getY() + 1).isWall()) {
				System.out.println("\nYou have hit a wall. Try a different direction.");
			} else if (moveDir.equals("A") && p.getX() > 0 && !maze.getTile(p.getX() - 1, p.getY()).isWall()) {
				p.moveLeft();
			} else if (moveDir.equals("A") && p.getX() == 0) {
				System.out.println("\nCannot leave the maze. Try a different direction.");
			} else if (moveDir.equals("A") && maze.getTile(p.getX() - 1, p.getY()).isWall()) {
				System.out.println("\nYou have hit a wall. Try a different direction.");
			} else if (moveDir.equals("S") && p.getY() > 0 && !maze.getTile(p.getX(), p.getY() - 1).isWall()) {
				p.moveDown();
			} else if (moveDir.equals("S") && p.getY() == 0) {
				System.out.println("\nCannot leave the maze. Try a different direction.");
			} else if (moveDir.equals("S") && maze.getTile(p.getX(), p.getY() - 1).isWall()) {
				System.out.println("\nYou have hit a wall. Try a different direction.");
			} else if (moveDir.equals("D") && p.getX() < mazeSize - 1
					&& !maze.getTile(p.getX() + 1, p.getY()).isWall()) {
				p.moveRight();
			} else if (moveDir.equals("D") && p.getX() == mazeSize - 1) {
				System.out.println("\nCannot leave the maze. Try a different direction.");
			} else if (moveDir.equals("D") && maze.getTile(p.getX() + 1, p.getY()).isWall()) {
				System.out.println("\nYou have hit a wall. Try a different direction.");
			} else {
				System.out.println("Invalid input.");
			}
		}

		/*
		 * after exiting the loop, whe must have hit one of the termination conditions.
		 * Here we just check which one it is and give corresponding feedback output to
		 * the user
		 */
		if (maze.getTile(p.getX(), p.getY()).isExit()) {
			System.out.println("Congratulations!! You have found the exit before running out of energy - you won!");
		} else {
			System.out.println("Oh no... you have run out of energy. Try again - if you dare!");
		}

		// close movement scanner to free up ressources
		sc.close();
	}

	// helper method to validate user input
	public static int validateInput(Scanner sc) {

		// variable to store user input
		int inputSize;

		// keep looping for new input, until a valid input is given
		while (true) {
			
			inputSize = sc.nextInt();
			/*
			 * this next line confused me for some time. Without it, I got 'Exception in
			 * thread "main" java.util.NoSuchElementException: No line found'. After doing
			 * some research, i found that after reading the size integer, it does not read
			 * the enter. So that enter remains in the input buffer and on the next call of
			 * the (or any) scanner (as they all read from the same stream), it reads that
			 * \n that remained in the buffer but finds no actual thing to read. The line
			 * below eats/flushes the buffer
			 */
			sc.nextLine();

			// only if input is valid, do we exit this loop and return the size
			if (inputSize > 1) {
				break;
			}

			System.out.println("\nInput must be greater than 1.\nSize:");
		}
		return inputSize;
	}

}

package sdvP_assign4;

import java.util.Random;

public class Maze {
	// variables as defined by instructions
	private Tile[][] grid;
	private int size;

	// constructor takes in a given size and creates the grid accordingly
	public Maze(int size) {
		this.size = size;
		// build the structure of the grid, after this line it's not filled/filled with
		// null references
		this.grid = new Tile[size][size];

		// therefore, this loop is needed to actually make each field a Tile object,
		// holding the information about wall and exit status
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				grid[i][j] = new Tile(false, false);
			}
		}

		// now it is time to place the walls and exit into the grid. to keep everything
		// clean and
		// modular, i decided to use a seperate method to assign them
		placeWallsAndExit();
	}

	// getters as defined by instructions
	public Tile getTile(int x, int y) {
		return grid[x][y];
	}

	public int getSize() {
		return size;
	}

	public void placeWallsAndExit() {

		// feedback output for user
		System.out.println("\nWalls and exit are being placed...");

		/*
		 * define a new randomizer which will later be used to chose wall and exit
		 * placement
		 */
		Random rand = new Random();

		/*
		 * define ~10% of the field to be walls, rounding to the closest int. That way,
		 * 2x2 has no walls which seems like good design. Recast to int is necessary,
		 * because Math.round returns long.
		 */
		int wallCount = (int) Math.round(size * size * 0.1);

		// loop as many times as there are walls to be placed
		for (int i = 0; i < wallCount; i++) {
			/*
			 * assign randoms to select wall placement, with range limited to size
			 * (exclusive, which is fine, bc indexing is -1)
			 */
			int x = rand.nextInt(size);
			int y = rand.nextInt(size);

			// generate new randoms in case they come to be the starting field or already
			// are a wall
			while ((x == 0 && y == 0) || grid[x][y].isWall()) {
				x = rand.nextInt(size);
				y = rand.nextInt(size);
			}

			// once a valid tile has been found, make it a wall
			grid[x][y] = new Tile(true, false);
		}

		// after placing all walls, find an empty tile to place the exit
		int x = rand.nextInt(size);
		int y = rand.nextInt(size);

		// generate new randoms in case they come to be the starting field or already
		// are a wall
		while ((x == 0 && y == 0) || grid[x][y].isWall()) {
			x = rand.nextInt(size);
			y = rand.nextInt(size);
		}

		// once a valid tile has been found, make it the exit
		grid[x][y] = new Tile(false, true);

		// feedback output for user
		System.out.println("\n... walls and exit have been successfuly placed.");
	}
}

// Declared abstract because it is not supposed to be instantiated
public abstract class Entity {

	// Attributes for position
	private int posX;
	private int posY;

	// Superclass contructor, so that class holds storing logic
	public Entity(int posX, int posY) {
		this.posX = posX;
		this.posY = posY;
	}

	// Getters are defined public to be accessed from anywhere within the project
	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	}

	// Even though all the classes are in the same package, which means all of them
	// can access this setter, it is defined as protected to show good practice
	// intent on encapsulation :) set both at the same time, even though only one is
	// updated per move. But they conceptually are one pair.
	protected void setPos(int posX, int posY) {
		this.posX = posX;
		this.posY = posY;
	}

	// Method for child classes to override;
	// Abstract, bc child classes don't have shared move behaviour
	public abstract void move(char direction, Map map);
}

import java.util.Random;

/*
 * As stated by instructions, this class stores the grid representation and tracks walls and treasures.
 * No separate tile class was asked for, allowing for a more lightweight implementation of the grid.
 * As one cell in the grid can only be either a wall, a treasure or empty we don't need tuples anyways.
 * We just encode what each cell is with a constant char.
 * note: java array is stored as array[row][column]. So for (x,y) coords we need to acces grid[y][x].
 * I think i even had that wrong in assignment 4
 */

public class Map {
	
	private char[][] grid;
	// Stores the grid size.
	private int size;	
	// Stores and tracks the treasures in the map.
	private int treasureCount;	
	// rand for placing walls and treasures.
	private Random rand = new Random();	
	// Define constants to assign cell values here once, so that unseen typos can happen later.
	private char EMPTY = '.';
	private char WALL = '#';
	private char TREASURE = '$';

	// Takes in the user spec grid size and calls method that builds the grid --> encapsulation
	public Map(int size) {
		this.size = size;
		buildGrid();
	}

	// Initialises and uses helper methods to fill grid --> encapsulation
	// Visibility private, bc it should be accessed only by constructor
	private char[][] buildGrid() {
		// Initialise the grid structure
		grid = new char[size][size];
		// Call helper methods that fill the grid cells
		fillEmpty();
		placeWalls();
		placeTreasures();
		return grid;
	}

	// Fills cells in initialised grid with EMPTY chars
	// Visibility private, bc it should be accessed only by buildGrid
	// Nothing to return as this helper does not create but modify and no local var used
	private void fillEmpty() {
		for (int y = 0; y < size; y++) {
			for (int x = 0; x < size; x++) {
				grid[y][x] = EMPTY;
			}
		}
	}

	// Places walls inside grid by replacing EMPTY with WALL in random cells.
	// Visibility private, bc it should be accessed only by buildGrid
	private void placeWalls() {
		// ~10% of grid = walls, rounding to the closest int.
		// That way, 2x2 has no walls which seems like good design.
		// Recast to int, bc Math.round returns long.
		int wallCount = (int) Math.round(size * size * 0.1);

		// Loop as often as there are walls to be placed.
		// Assign randoms to select wall placement, with range limited to size.
		// New randoms in case they come to be the starting field or already are a wall
		for (int i = 0; i < wallCount; i++) {
			
			int x = rand.nextInt(size);
			int y = rand.nextInt(size);

			while ((x == 0 && y == 0) || isWall(x, y)) {
				x = rand.nextInt(size);
				y = rand.nextInt(size);
			}
			
			// Once a valid cell has been found, make it a wall
			grid[y][x] = WALL;
		}
	}

	// Places treasures inside the grid by replacing EMPTY with TREASURE in random cells.
	// Visibility private, bc it should be accessed only by buildGrid
	private void placeTreasures() {

		// ~10% of grid = treasures, rounding to closest int.
		// Recast to int, because Math.round returns long.
		treasureCount = (int) Math.round(size * size * 0.1);
		
		// If size <= 2, 1 treasure instead of 0 so that win cond can be reached.
		// Smaller than 2 is implemented not to be allowed in main, but encapsulate reachable win con here.
		if(size <= 2) {
			treasureCount = 1;
		}
			
		// Loop as often as there are treasures to be placed.
		// Assign randoms to select treasure placement, with range limited to size.
		// New randoms in case they come to be the starting field or already are a wall or treasure
		for (int i = 0; i < treasureCount; i++) {

			int x = rand.nextInt(size);
			int y = rand.nextInt(size);

			while ((x == 0 && y == 0) || isWall(x, y) || hasTreasure(x, y)) {
				x = rand.nextInt(size);
				y = rand.nextInt(size);
			}

			// Once a valid cell has been found, make it a treasure
			grid[y][x] = TREASURE;
		}
	}

	// Checks if a cell is WALL
	// Visibility public, because it will be accessed by other classes.
	public boolean isWall(int x, int y) {
		return grid[y][x] == WALL;
	}

	// Checks if a cell is TREASURE
	// Visibility public, because it will be accessed by other classes.
	public boolean hasTreasure(int x, int y) {
		return grid[y][x] == TREASURE;
	}

	public int getSize() {
		return size;
	}
	
	public int getTreasureCount() {
		return treasureCount;
	}
	
	// Removes treasures in grid by replacing TREASURE with EMPTY.
	// Visibility public, because it will be accessed by other classes.
	public void removeTreasure(int x, int y) {
		grid[y][x] = EMPTY;
		treasureCount--;
	}
	
	// Checks if win con has been reached
	// Visibility public, because it will be accessed by other classes.
	public boolean detectWin() {
		return treasureCount == 0;
	}
	
	// Checks if lose con has been reached
	// Visibility public, because it will be accessed by other classes.
	public boolean detectLose(Player p, Guard g) {
		return p.getPosX() == g.getPosX() && p.getPosY() == g.getPosY();
	}
}

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * As stated by instructions, Main creates map and entities, stores the latter in an ArrayList.
 * It validates user input and controls the game loop.
 * Two bugs can happen in this game (that I'm aware of):
 * Start position of player is enclosed by walls: Player can't move. Game never ends.
 * Starting position of guard in enclosed by walls: Guard cant't move. Endless loop on finding new random direction.
 * Omid said that's okay for assignment 4, so i assume it's okay for assignment 5 as well. :)
 * Note: If player tries to move out of map or into wall, guard move regardless. I think that's just a design choice.
 * Also design choice: Guard can't move through walls, but onto treasures; number of walls & treasures; ...
 */
public class Main {

	public static void main(String[] args) {
		// Scanner for user input
		Scanner sc = new Scanner(System.in);

		// Game start user output
		System.out.println("Welcome player. So... you think you have what it takes to find all the treasures. "
				+ "All those treasures, that so many have tried to claim for themselves already.\n"
				+ "But no one has managed to slip by ME before - FRITZ, THE GUARD! HA! "
				+ "As if you were any different... I assume you've heard the rules already.\n"
				+ "So, enter your desired grid size:");

		// Read user spec map size
		int mapSize = validateSize(sc);
		// Instantiate map
		Map map = new Map(mapSize);

		// Give corresponding output for the user
		System.out.println("\nA maze with the chosen size of " + map.getSize() + " x " + map.getSize()
				+ " has been created. There is a total of " + map.getTreasureCount() + " treasures to find.");

		// Create ArrayList and entities and add them to the list
		List<Entity> entities = new ArrayList<>();
		Player p = new Player();
		Guard g = new Guard(map);

		entities.add(p);
		entities.add(g);

		// Game loop continues until win or lose con introduces a break
		while (true) {
			// User output, displaying current pos, potential inputs
			System.out.println("\nYour current position is (" + p.getPosX() + ", " + p.getPosY() + ")"
					+ "\n\nPress\nW to move up\nA to move left\nS to move down\nD to move right");

			// Read input as string first, to not go outofbounds on empty input
			String input = sc.nextLine().toUpperCase();

			// Validate input is one of the four options
			// Restart game loop if input invalid
			if (!input.equals("W") && !input.equals("A") && !input.equals("S") && !input.equals("D")) {
				System.out.println("\nInvalid input.");
				continue;
			}

			// Assign validated input to char for move-method call
			char direction = input.charAt(0);

			// Loop over ArrayList, call move-method depending on type of entry
			// This allows for adding/removing more entities later, making use of the list
			// g.move is invoked with hardcoded char, gets ignored anyway
			for (Entity e : entities) {
				if (e instanceof Player) {
					p.move(direction, map);
				} else if (e instanceof Guard) {
					g.move(' ', map);
				}
			}

			// Check if win or lose con has been reached. If so, give output and terminate loop
			if (map.detectWin()) {
				System.out.println(
						"Wha.. What?! How can this be?! You FOUND ALL the TREASURES!! Maybe I should retire my guarding duty... YOU WIN!");
				break;
			} else if (map.detectLose(p, g)) {
				System.out.println("I told you I was not easy to beat. I CAUGHT YOU, this is GAME OVER for you!");
				break;
			}
		}

		// Close movement scanner to free up ressources
		sc.close();
	}

	// Helper method to validate user input
	public static int validateSize(Scanner sc) {

		// Stores user input
		int inputSize;

		// Keep looping for new input, until a valid input is given
		while (true) {

			inputSize = sc.nextInt();

			// Explained in assignment 4 already
			sc.nextLine();

			// On valid input, terminate loop and return size
			if (inputSize > 1) {
				break;
			}

			System.out.println("\nInput must be greater than 1.\nSize:");
		}
		return inputSize;
	}
}

// Extends abstract entity class for player objects and defines keyboard input movement
public class Player extends Entity {
	// Stores collected treasures
	private int treasuresFound;

	// Calls super contructor with forced starting position (0,0)
	public Player() {
		super(0, 0);
		treasuresFound = 0;
	}

	// Implements player movement.
	// For each direction, check corresponding grid bounds and potential walls.
	// If everything ok, update position. Else, give appropriate output.
	// After move, check for treasure. If found, update count and give output.
	@Override
	public void move(char direction, Map map) {
		
		if (direction == 'W' && getPosY() + 1 < map.getSize() && !map.isWall(getPosX(), getPosY() + 1)) {
			setPos(getPosX(), getPosY() + 1);
		} else if (direction == 'W' && getPosY() + 1 == map.getSize()) {
			System.out.println("You can't leave the grid. Choose a different direction.");
		} else if (direction == 'W' && map.isWall(getPosX(), getPosY() + 1)) {
			System.out.println("You hit a wall. Choose a different direction.");
		} else if (direction == 'S' && getPosY() != 0 && !map.isWall(getPosX(), getPosY() - 1)) {
			setPos(getPosX(), getPosY() - 1);
		} else if (direction == 'S' && getPosY() == 0) {
			System.out.println("You can't leave the grid. Choose a different direction.");
		} else if (direction == 'S' && map.isWall(getPosX(), getPosY() - 1)) {
			System.out.println("You hit a wall. Choose a different direction.");
		} else if (direction == 'A' && getPosX() != 0 && !map.isWall(getPosX() - 1, getPosY())) {
			setPos(getPosX() - 1, getPosY());
		} else if (direction == 'A' && getPosX() == 0) {
			System.out.println("You can't leave the grid. Choose a different direction.");
		} else if (direction == 'A' && map.isWall(getPosX() - 1, getPosY())) {
			System.out.println("You hit a wall. Choose a different direction.");
		} else if (direction == 'D' && getPosX() + 1 < map.getSize() && !map.isWall(getPosX() + 1, getPosY())) {
			setPos(getPosX() + 1, getPosY());
		} else if (direction == 'D' && getPosX() + 1 == map.getSize()) {
			System.out.println("You can't leave the grid. Choose a different direction.");
		} else if (direction == 'D' && map.isWall(getPosX() + 1, getPosY())) {
			System.out.println("You hit a wall. Choose a different direction.");
		}

		if (map.hasTreasure(getPosX(), getPosY())) {
			map.removeTreasure(getPosX(), getPosY());
			treasuresFound++;
			System.out.println("You found a treasure!\nYou have collected " + treasuresFound + " treasure so far. "
					+ map.getTreasureCount() + " to go.");
		}
	}

}

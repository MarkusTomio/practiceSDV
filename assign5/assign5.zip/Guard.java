import java.util.Random;

// Extends abstract entity class for guard objects and defines random movement
public class Guard extends Entity{
	// Used for random move directions
	private Random rand = new Random();
	
	// Calls super contructor with (0,0) temporarily, then finds valid random start pos
	// Temporary super() is necessary, bc it has to be first call in constructor
	// Needs map to locate a valid start pos
	public Guard(Map map) {
		super(0,0);
		setValidStart(map);
	}
	
	// Generate random start pos until it's not player start and wall
	// Update start pos with a valid one
	private void setValidStart(Map map) {
		int startX = rand.nextInt(map.getSize());
		int startY = rand.nextInt(map.getSize());
		while(startX == 0 & startY == 0 || map.isWall(startX, startY)) {
			startX = rand.nextInt(map.getSize());
			startY = rand.nextInt(map.getSize());
		}
		setPos(startX, startY);
	}
	
	// Implements guard movement via randomly generated int [0,1,2,3].
	// For each direction, check corresponding grid bounds and potential walls.
	// Generate new direction until valid one is found.
	// Then, update position.
	@Override
	public void move(char direction, Map map) {
		int guardDir = rand.nextInt(4);
		
		while(guardDir == 0 && getPosY() + 1 == map.getSize() || guardDir == 0 && map.isWall(getPosX(), getPosY() + 1)
				|| guardDir == 1 && getPosY() == 0 || guardDir == 1 && map.isWall(getPosX(), getPosY() - 1)
				|| guardDir == 2 && getPosX() == 0 || guardDir == 2 && map.isWall(getPosX() - 1, getPosY())
				|| guardDir == 3 && getPosX() + 1 == map.getSize() || guardDir == 3 && map.isWall(getPosX() + 1, getPosY())) {
			guardDir = rand.nextInt(4);
		}
		
		if (guardDir == 0) {
			setPos(getPosX(), getPosY() + 1);
		} else if (guardDir == 1) {
			setPos(getPosX(), getPosY() - 1);
		} else if (guardDir == 2) {
			setPos(getPosX() - 1, getPosY());
		}  else if (guardDir == 3) {
			setPos(getPosX() + 1, getPosY());
		}
	}

}
